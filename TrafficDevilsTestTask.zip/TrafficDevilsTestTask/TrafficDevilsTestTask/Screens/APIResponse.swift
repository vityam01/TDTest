//
//  APIResponse.swift
//  TrafficDevilsTestTask
//
//  Created by Vitya Mandryk on 11.02.2024.
//

import Foundation

struct APIResponse: Codable {
    let winner: String
    let loser: String
}
